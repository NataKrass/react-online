# React online marathon

## The tasks of the topic "Gulp"

There is the file <code>gulpfile.js</code>

Configure it to specify (if you use any extras plugins describe them in the <code>package.json</code>, as appropriate):

1. Create the task will take all the <code>js</code> files located in the <code>src</code>
directory and its subdirectories recursively and concatenate them into one <code>output/result.js</code> file
2. Create the task will take all the <code>css</code> files located in the <code>src</code>
directory and its subdirectories recursively and concatenate them into one <code>output/result.css</code> file
3. Define the public default task will run the tasks described above
