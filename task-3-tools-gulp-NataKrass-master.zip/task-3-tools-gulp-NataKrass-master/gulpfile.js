
var gulp = require("gulp");
concat = require('gulp-concat');

function taskJs(){
    return gulp.src("src/**/*.js")
    .pipe(concat("result.js"))
    .pipe(gulp.dest("output"));
};
function taskCss(){
  return gulp.src("src/**/*.css")
    .pipe(concat("result.css")) 
    .pipe(gulp.dest("output"))
}

gulp.task("default", gulp.series(taskJs, taskCss))


